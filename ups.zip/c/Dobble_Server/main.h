
/* 
 * File:   main.h
 * Author: anvy
 *
 * Created on 1. listopadu 2016, 14:00
 */

#ifndef MAIN_H
#define MAIN_H

int port_control(char *argv) ;

#endif /* MAIN_H */

