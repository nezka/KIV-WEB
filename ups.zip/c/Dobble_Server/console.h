
#ifndef CONSOLE_H
#define CONSOLE_H

#define CONSOLE_BUFF 6

void *console_listening(void *param);

#endif /* THREADS_H */

