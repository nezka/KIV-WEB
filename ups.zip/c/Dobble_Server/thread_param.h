/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   thread_param.h
 * Author: anvy
 *
 * Created on 19. ledna 2017, 2:40
 */

#ifndef THREAD_PARAM_H
#define THREAD_PARAM_H


typedef struct thread_param {
    int port;
    int should_run;
} thread_param;


#endif /* THREAD_PARAM_H */

